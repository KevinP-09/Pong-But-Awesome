extends Timer

var ball_ref = null
const EVENT_DURATION := 5.0

func _ready() -> void:
	ball_ref = get_parent().get_node("Ball")
	timeout.connect(_on_timeout)

func _on_timeout() -> void:
	_trigger_giant_ball()

func _trigger_giant_ball() -> void:
	ball_ref.scale = Vector2(3, 3)
	await get_tree().create_timer(EVENT_DURATION).timeout
	ball_ref.scale = Vector2(1, 1)
