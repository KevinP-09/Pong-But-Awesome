extends CharacterBody2D

var win_size : Vector2
const START_SPEED : int = 300
const ACCEL : int = 50
var speed : int
var dir : Vector2
const MAX_Y_VECTOR : float = 0.6

var invulnerable_to = null

const SLING_LAUNCH_BONUS := 600

var held := false
var held_by = null
var held_charging := false
var held_charge_time := 0.0
var held_timer := 0.0

const HELD_TIMEOUT := 5.0
const HELD_OFFSET := 60.0
const SERVE_MAX_CHARGE_TIME := 1.4
const SERVE_MAX_HOLD_TIME := 3.0

var in_play := true
var game_over := false

var events_started := false
var event_timer := 5.0
const EVENT_INTERVAL := 5.0
const EVENT_DURATION := 7.0
var event_active := false
var event_type_active = null
var event_duration_timer := 0.0
var event_flash_time := 0.0

var scoring_message := ""
var showing_score_message := false

enum Event { GIANT_BALL, DONT_MOVE, HOT_POTATO, WRAP }
var event_pool := [Event.GIANT_BALL, Event.DONT_MOVE, Event.HOT_POTATO, Event.WRAP]

var dont_move_grace_timer := 0.0
const DONT_MOVE_GRACE_TIME := 0.5
var dont_move_active := false
var dont_move_timer := 0.0
var dont_move_violating := false
var dont_move_violator = null
var dont_move_shake_timer := 0.0
var dont_move_base_pos := Vector2.ZERO
var dont_move_reaction_timer := 0.0
var dont_move_reaction_paddle = null
var dont_move_slamming := false
var dont_move_slam_target = null
const DONT_MOVE_SHAKE_TIME := 1.5
const DONT_MOVE_SLAM_SPEED := 2000.0
const DONT_MOVE_REACTION_TIME := 0.1
const HURT_DURATION := 2.0

var wrap_grace_timer := 0.0
const WRAP_GRACE_TIME := 0.2
const WRAP_TELEPORT_OFFSET := 40.0

func _ready():
	await get_tree().process_frame
	win_size = get_viewport_rect().size
	$ServeTimerLabel.top_level = true

func _set_invulnerable(paddle) -> void:
	if invulnerable_to and invulnerable_to != paddle:
		remove_collision_exception_with(invulnerable_to)
	if paddle and paddle != invulnerable_to:
		add_collision_exception_with(paddle)
	invulnerable_to = paddle

func new_ball(serve_dir_x := 0):
	position.x = win_size.x / 2
	position.y = randi_range(200, win_size.y - 200)
	speed = START_SPEED
	dir = random_direction(serve_dir_x)
	_set_invulnerable(null)
	held = false
	held_by = null
	held_charging = false
	in_play = true

func random_direction(x_override := 0):
	var new_dir := Vector2()
	if x_override != 0:
		new_dir.x = x_override
	else:
		new_dir.x = [1, -1].pick_random()
	new_dir.y = randf_range(-1, 1)
	return new_dir.normalized()

func start_held_serve(paddle) -> void:
	held = true
	held_by = paddle
	held_charging = false
	held_charge_time = 0.0
	held_timer = HELD_TIMEOUT
	_set_invulnerable(null)
	speed = 0
	in_play = true
	if paddle.has_method("reset_charge_state"):
		paddle.reset_charge_state()
	position.y = paddle.position.y
	position.x = paddle.position.x + paddle.sling_direction * HELD_OFFSET

func pause_events_for_score(scorer_label: String) -> void:
	in_play = false
	_cancel_active_event()
	event_timer = EVENT_INTERVAL
	scoring_message = scorer_label + " SCORES!"
	showing_score_message = true

func _cancel_active_event() -> void:
	if event_active:
		scale = Vector2(1, 1)
		modulate.a = 1.0
		$"../Player1".frozen = false
		$"../Player2".frozen = false
		dont_move_active = false
		dont_move_violating = false
		dont_move_reaction_paddle = null
		dont_move_slamming = false
		dont_move_slam_target = null
		dont_move_grace_timer = 0.0
		wrap_grace_timer = 0.0
	event_active = false
	event_type_active = null

func start_events() -> void:
	events_started = true
	event_timer = EVENT_INTERVAL

func end_game() -> void:
	game_over = true
	$"../hud/EventTimer".visible = false

func reset_for_new_game() -> void:
	game_over = false
	event_active = false
	event_type_active = null
	events_started = false
	scale = Vector2(1, 1)
	modulate.a = 1.0
	showing_score_message = false
	scoring_message = ""
	$"../hud/EventTimer".visible = true

func _physics_process(delta):
	_update_events(delta)

	if event_active:
		event_flash_time += delta

		if event_type_active == Event.GIANT_BALL:
			event_duration_timer -= delta
			if event_duration_timer <= 0.0:
				scale = Vector2(1, 1)
				event_active = false
				event_type_active = null
		elif event_type_active == Event.HOT_POTATO:
			event_duration_timer -= delta
			modulate.a = 1.0 if fmod(event_flash_time, 0.26) < 0.13 else 0.3
			if event_duration_timer <= 0.0:
				_end_hot_potato()
		elif event_type_active == Event.WRAP:
			event_duration_timer -= delta
			if wrap_grace_timer > 0.0:
				wrap_grace_timer -= delta
			if event_duration_timer <= 0.0:
				event_active = false
				event_type_active = null

	_update_labels()

	if held:
		_process_held(delta)
		return

	if dont_move_active:
		_process_dont_move(delta)
		return

	var collision = move_and_collide(dir * speed * delta)
	if collision:
		var collider = collision.get_collider()
		if collider == $"../Player1" or collider == $"../Player2":
			if collider.slinging and collider.sling_phase == "out":
				collider.sling_phase = "return"
				var dist = abs(collider.original_x - collider.position.x)
				collider.sling_speed = dist / collider.SLING_RETURN_TIME
				apply_sling_hit(collider, collider.current_charge_fraction)
			else:
				register_hit(collider)
		elif event_active and event_type_active == Event.WRAP and wrap_grace_timer <= 0.0 and abs(collision.get_normal().y) > abs(collision.get_normal().x):
			var hit_top = collision.get_normal().y > 0
			if hit_top:
				position.y = win_size.y - WRAP_TELEPORT_OFFSET
			else:
				position.y = WRAP_TELEPORT_OFFSET
		else:
			_set_invulnerable(null)
			dir = dir.bounce(collision.get_normal())
			var remainder_length = collision.get_remainder().length()
			if remainder_length > 0.0:
				move_and_collide(dir * remainder_length)

func _process_held(delta: float) -> void:
	held_timer -= delta
	if not held_charging:
		position.y = held_by.position.y
		position.x = held_by.position.x + held_by.sling_direction * HELD_OFFSET
	if held_timer <= 0.0:
		launch_random_from_holder(held_by)

func launch_random_from_holder(paddle) -> void:
	if not held or held_by != paddle:
		return
	held = false
	held_by = null
	held_charging = false
	showing_score_message = false
	speed = START_SPEED
	var new_dir := Vector2()
	new_dir.x = paddle.sling_direction
	new_dir.y = randf_range(-1, 1)
	dir = new_dir.normalized()
	_set_invulnerable(paddle)

func start_charge(paddle) -> void:
	if not held or held_by != paddle or held_charging:
		return
	held_charging = true
	held_charge_time = 0.0

func update_charge(paddle, delta: float) -> void:
	if not held or held_by != paddle or not held_charging:
		return
	held_charge_time += delta
	if held_charge_time >= SERVE_MAX_HOLD_TIME:
		release_charge(paddle)

func release_charge(paddle) -> void:
	if not held or held_by != paddle or not held_charging:
		return
	var dist = position.y - paddle.position.y
	if abs(dist) > paddle.p_height / 2.0:
		held_charging = false
		return
	var charge_fraction = min(held_charge_time / SERVE_MAX_CHARGE_TIME, 1.0)
	var new_dir := Vector2()
	new_dir.x = paddle.sling_direction
	new_dir.y = (dist / (paddle.p_height / 2)) * MAX_Y_VECTOR
	dir = new_dir.normalized()
	speed = START_SPEED + SLING_LAUNCH_BONUS * charge_fraction
	held = false
	held_by = null
	held_charging = false
	showing_score_message = false
	_set_invulnerable(paddle)

func register_hit(collider) -> void:
	speed += ACCEL
	dir = new_direction(collider)
	_set_invulnerable(collider)

func new_direction(collider):
	var ball_y = position.y
	var pad_y = collider.position.y
	var dist = ball_y - pad_y
	var new_dir := Vector2()
	if collider == $"../Player1":
		new_dir.x = 1
	else:
		new_dir.x = -1
	new_dir.y = (dist / (collider.p_height / 2)) * MAX_Y_VECTOR
	return new_dir.normalized()

func apply_sling_hit(paddle, charge_fraction: float) -> void:
	var pad_y = paddle.position.y
	var dist = position.y - pad_y
	var new_dir := Vector2()
	new_dir.x = paddle.sling_direction
	new_dir.y = (dist / (paddle.p_height / 2)) * MAX_Y_VECTOR
	dir = new_dir.normalized()
	var sling_speed_result = START_SPEED + SLING_LAUNCH_BONUS * charge_fraction
	speed = max(speed + ACCEL, sling_speed_result)
	_set_invulnerable(paddle)

func _on_hitbox_body_entered(body, paddle) -> void:
	if body != self:
		return
	if paddle.slinging:
		apply_sling_hit(paddle, paddle.current_charge_fraction)
	else:
		register_hit(paddle)

func _update_events(delta: float) -> void:
	if not events_started or event_active or held or not in_play or game_over:
		return
	event_timer -= delta
	if event_timer <= 0.0:
		event_timer = EVENT_INTERVAL
		_trigger_random_event()

func _trigger_random_event() -> void:
	var event = event_pool.pick_random()
	event_active = true
	event_type_active = event
	event_flash_time = 0.0
	match event:
		Event.GIANT_BALL:
			_event_giant_ball()
		Event.DONT_MOVE:
			_event_dont_move()
		Event.HOT_POTATO:
			_event_hot_potato()
		Event.WRAP:
			_event_wrap()

func _event_giant_ball() -> void:
	scale = Vector2(12, 12)
	event_duration_timer = EVENT_DURATION

func _event_hot_potato() -> void:
	event_duration_timer = EVENT_DURATION

func _end_hot_potato() -> void:
	event_active = false
	event_type_active = null
	modulate.a = 1.0
	if invulnerable_to and invulnerable_to.has_method("enter_hurt_state"):
		invulnerable_to.enter_hurt_state(HURT_DURATION)

func _event_wrap() -> void:
	event_duration_timer = EVENT_DURATION
	wrap_grace_timer = WRAP_GRACE_TIME

func _event_dont_move() -> void:
	dont_move_active = true
	dont_move_timer = EVENT_DURATION
	dont_move_violating = false
	dont_move_violator = null
	dont_move_reaction_paddle = null
	dont_move_reaction_timer = 0.0
	dont_move_slamming = false
	dont_move_slam_target = null
	dont_move_grace_timer = DONT_MOVE_GRACE_TIME

func report_dont_move_input(paddle) -> void:
	if not dont_move_active or dont_move_violating or dont_move_slamming or dont_move_reaction_paddle != null:
		return
	if dont_move_grace_timer > 0.0:
		return
	dont_move_reaction_paddle = paddle
	dont_move_reaction_timer = DONT_MOVE_REACTION_TIME

func _process_dont_move(delta: float) -> void:
	if dont_move_grace_timer > 0.0:
		dont_move_grace_timer -= delta

	if dont_move_slamming:
		var target_pos = dont_move_slam_target.position
		dir = (target_pos - position).normalized()
		var collision = move_and_collide(dir * speed * delta)
		if collision:
			var collider = collision.get_collider()
			dont_move_slamming = false
			dont_move_active = false
			event_active = false
			event_type_active = null
			$"../Player1".frozen = false
			$"../Player2".frozen = false
			if collider == $"../Player1" or collider == $"../Player2":
				register_hit(collider)
				if collider.has_method("enter_hurt_state"):
					collider.enter_hurt_state(HURT_DURATION)
			else:
				_set_invulnerable(null)
				dir = dir.bounce(collision.get_normal())
		return

	if dont_move_reaction_paddle and not dont_move_violating:
		dont_move_reaction_timer -= delta
		if dont_move_reaction_timer <= 0.0:
			dont_move_reaction_paddle.frozen = true
			dont_move_violating = true
			dont_move_violator = dont_move_reaction_paddle
			dont_move_shake_timer = DONT_MOVE_SHAKE_TIME
			dont_move_base_pos = position

	if dont_move_violating:
		dont_move_shake_timer -= delta
		var jitter_offset = Vector2(randf_range(-3, 3), randf_range(-3, 3))
		var target_pos = dont_move_base_pos + jitter_offset
		var move_delta = target_pos - position
		move_and_collide(move_delta)
		if dont_move_shake_timer <= 0.0:
			dont_move_violating = false
			dont_move_slamming = true
			dont_move_slam_target = dont_move_violator
			speed = DONT_MOVE_SLAM_SPEED
			_set_invulnerable(null)
		return

	dont_move_timer -= delta
	if dont_move_timer <= 0.0:
		$"../Player1".frozen = false
		$"../Player2".frozen = false
		dont_move_active = false
		event_active = false
		event_type_active = null

func _update_labels() -> void:
	if game_over:
		return

	if showing_score_message:
		$"../hud/EventTimer".visible = true
		$"../hud/EventTimer".text = scoring_message
	elif event_active:
		match event_type_active:
			Event.GIANT_BALL:
				$"../hud/EventTimer".text = "GIANT BALL!"
			Event.DONT_MOVE:
				$"../hud/EventTimer".text = "DON'T MOVE!"
			Event.HOT_POTATO:
				$"../hud/EventTimer".text = "HOT POTATO!"
			Event.WRAP:
				$"../hud/EventTimer".text = "NO WALLS!"
		$"../hud/EventTimer".visible = fmod(event_flash_time, 0.26) < 0.13
	elif events_started:
		$"../hud/EventTimer".visible = true
		$"../hud/EventTimer".text = "%d" % ceil(event_timer)
	else:
		$"../hud/EventTimer".visible = true
		$"../hud/EventTimer".text = ""

	$ServeTimerLabel.global_position = global_position + Vector2(-8, -60)
	if held:
		$ServeTimerLabel.text = "%d" % ceil(held_timer)
	elif event_active and event_type_active == Event.HOT_POTATO:
		$ServeTimerLabel.text = "%d" % ceil(event_duration_timer)
	else:
		$ServeTimerLabel.text = ""
